// JAT v11 — autofill + answer-learning engine.
// Port of v9's best asset (content/autofill.js) with three upgrades:
//  • shadow-DOM-piercing field scans (Workday) via lib/dom.js
//  • native-setter value injection everywhere (defeats controlled React inputs;
//    v9 only used it in the fallback path)
//  • profile/qa I/O is injected, so the executor wires it to the desktop app's
//    SQLite qa store instead of IndexedDB.

import { qsa, isProbablyVisible } from './lib/dom.js';

export const PROFILE_PATTERNS = [
  [/(first.*name|given.*name|prénom|prenom|nombre|vorname)/i, 'firstName'],
  [/(last.*name|family.*name|surname|nom de famille|apellido|nachname)/i, 'lastName'],
  [/(full.*name|legal.*name|^name$|nom complet|nombre completo)/i, 'fullName'],
  [/(preferred.*name|nickname|prefer.*to.*be.*called)/i, 'preferredName'],
  [/(pronoun|pronouns)/i, 'pronouns'],
  [/(email|courriel|correo|e-mail|mail)/i, 'email'],
  [/(phone|mobile|cell|téléphone|telefono|telefon)/i, 'phone'],
  [/(address.*2|apartment|unit|suite|appartement)/i, 'address2'],
  [/(address|street|adresse|dirección)/i, 'address1'],
  [/(city|ville|ciudad|stadt)/i, 'city'],
  [/(province|state|région|estado|bundesland)/i, 'state'],
  [/(postal|zip|code postal|código postal|plz)/i, 'postalCode'],
  [/(country|pays|país|land)/i, 'country'],
  [/(linkedin)/i, 'linkedinUrl'],
  [/(github)/i, 'githubUrl'],
  [/(portfolio|website|site web|sitio web)/i, 'portfolioUrl'],
  [/(authoriz|eligible.*work|right.*to.*work|autoris)/i, 'workAuthorization'],
  [/(sponsor|visa|sponsorship)/i, 'sponsorshipRequired'],
  [/(salary.*expect|compensation.*expect|expected.*salary|salaire|salario)/i, 'salaryExpectation'],
  [/(year.*experience|years.*of.*exp|expérience|experiencia|years.*exp)/i, 'yearsExperience'],
  [/(notice|start.*date|disponibilité|disponibilidad|earliest)/i, 'noticePeriod'],
  [/(highest.*degree|education.*level|degree)/i, 'highestDegree'],
  [/(university|college|école|universidad|universität)/i, 'university'],
  [/(graduation.*year|year.*graduated|année.*diplôme)/i, 'graduationYear'],
  [/(major|field of study|spécialité)/i, 'major'],
  [/(headline|^title$)/i, 'headline'],
  [/(summary|about you|brief)/i, 'summary'],
  [/(citizen|citizenship|citoyen|ciudadanía)/i, 'citizenship'],
  [/(security.*clearance|habilitation)/i, 'securityClearance'],
];

function stripAccents(s) {
  try { return s.normalize('NFKD').replace(/[̀-ͯ]/g, ''); } catch { return s; }
}

// Placeholder strings that describe the WIDGET, not the question — "Search to select an option",
// "Select…", "Start typing". They must never become a field's label: the answer layer then sees a
// prompt containing no question and refuses (correctly), which parks the whole application.
const GENERIC_PLACEHOLDER_RX = /^\s*(?:search(?:\s+to\s+select(?:\s+an?\s+option)?)?|select(?:\s+an?)?(?:\s+(?:option|answer|one))?|choose(?:\s+an?)?(?:\s+(?:option|one))?|start\s+typing|type\s+to\s+search|please\s+select|-{1,2}\s*select\s*-{0,2}|n\/?a)\s*[.…]{0,3}\s*$/i;
export function isGenericPlaceholder(s) {
  const t = String(s || '').trim();
  if (!t) return true;
  return GENERIC_PLACEHOLDER_RX.test(t);
}

// Map a NUMERIC answer onto a RANGE option. Experience dropdowns are ranges — "Less than 1 year",
// "1-3 years", "5-10 years", "More than 10 years" — while the profile holds a plain number ("6").
// Text matching can never connect the two: "6" is not a substring of "5-10 years", so the field was
// left unselected and the form refused to advance. Returns the index of the option whose range
// contains the number, or -1 when the value is not numeric or no range fits.
// PURE + exported so the arithmetic is node-testable without a DOM.
export function matchNumericRangeOption(value, optionTexts) {
  const raw = String(value == null ? '' : value).trim();
  if (!/^\d{1,2}(?:\.\d+)?$/.test(raw)) return -1;         // only a bare number answers a range
  const n = Number(raw);
  if (!Number.isFinite(n)) return -1;
  const opts = (Array.isArray(optionTexts) ? optionTexts : []).map((t) => String(t || '').toLowerCase());
  let fallbackMax = -1, fallbackMaxVal = -Infinity;
  for (let i = 0; i < opts.length; i++) {
    const t = opts[i];
    if (!t) continue;
    // "less than 1 year" / "under 1 year" / "<1"
    let m = t.match(/(?:less than|under|fewer than|<)\s*(\d{1,2})/);
    if (m && n < Number(m[1])) return i;
    // "more than 10 years" / "over 10" / "10+" / "at least 10"
    m = t.match(/(?:more than|over|at least|>=?|(\d{1,2})\s*\+)\s*(\d{1,2})?/);
    if (m) {
      const bound = Number(m[1] ?? m[2]);
      if (Number.isFinite(bound) && /(?:more than|over|at least|\+|>)/.test(t)) {
        if (n >= bound) { if (bound > fallbackMaxVal) { fallbackMaxVal = bound; fallbackMax = i; } }
        continue;
      }
    }
    // "1-3 years" / "1 to 3 years" / "3 – 5"
    m = t.match(/(\d{1,2})\s*(?:-|–|—|to)\s*(\d{1,2})/);
    if (m) {
      const lo = Number(m[1]), hi = Number(m[2]);
      if (n >= lo && n <= hi) return i;
    }
  }
  return fallbackMax;    // e.g. 12 with options topping out at "more than 10 years"
}

// A text input that is really a SEARCHABLE SELECT: you must type and then PICK an option, and
// typing alone leaves the widget unselected (the form then refuses to advance while the field
// looks filled). Detected from a placeholder that implies CHOOSING — "Search to select an option",
// "Select an option", "Choose one". Deliberately requires select/choose: a bare "Search…" box stays
// plain text, so a real free-text field is never rerouted.
const SEARCHABLE_SELECT_PLACEHOLDER_RX = /\b(?:select|choose|s[ée]lectionn|choisir)\b/i;
export function looksLikeSearchableSelect(input) {
  try {
    if (!input || input.tagName !== 'INPUT') return false;
    const type = String(input.type || 'text').toLowerCase();
    if (type !== 'text' && type !== 'search') return false;
    return SEARCHABLE_SELECT_PLACEHOLDER_RX.test(String(input.placeholder || ''));
  } catch { return false; }
}

// Last-resort label: the real question often sits in an ancestor block ABOVE the widget (the same
// shape as Indeed's stacked labels). Walk up a few levels, strip out nested form controls so we
// read the PROMPT rather than the options, and take the nearest sensible text. Prefers an actual
// question sentence when the block contains one.
// maxUp was 5, which is not deep enough for react-select. Greenhouse nests the role=combobox input
// SEVEN levels below the block holding the question:
//   input → .select__input-container → .select__value-container → .select__control
//         → .select-shell → .select__container → .select → .field-wrapper(question)
// so the walk gave up, fieldLabel returned '', and scanUnknown dropped the field on its
// `label.length < 4` guard — the required screening question was never even surfaced
// (live: `trace:scan fillable=0 … unknown=0` on a form with 5 required questions).
// Depth alone is not safe though: keep climbing and you eventually swallow the whole form and
// blend several questions together. So the walk now stops the moment it leaves THIS field's own
// wrapper — an ancestor containing more than one real control covers several questions. The
// aria-hidden validation sentinel react-select puts beside the combobox is not a real control and
// must not count, or the walk would stop one level short of the question every time.
export function nearestQuestionText(input, maxUp = 8) {
  try {
    let el = input.parentElement;
    for (let i = 0; i < maxUp && el; i++) {
      try {
        const controls = el.querySelectorAll?.('input:not([type="hidden"]):not([aria-hidden="true"]), select, textarea');
        if (controls && controls.length > 1) break;
      } catch { /* keep climbing */ }
      let txt = '';
      try {
        const clone = el.cloneNode(true);
        // Widget chrome is not part of the question. react-select renders its "Select…" prompt as
        // a *div* (.select__placeholder), so element-type stripping alone leaves it glued to the
        // front of the recovered label — "select... do you now, or will you in the future, …".
        clone.querySelectorAll?.('input, select, textarea, button, option, [role="combobox"], [role="listbox"], [role="option"], [class*="placeholder" i]')
          .forEach((n) => n.remove());
        txt = String(clone.textContent || '').replace(/\s+/g, ' ').trim();
      } catch { txt = ''; }
      if (txt && txt.length >= 8 && txt.length <= 220 && !isGenericPlaceholder(txt)) {
        // If the block holds a question, prefer that sentence over surrounding boilerplate.
        const q = txt.match(/[^.?!]*\?/g);
        return (q && q.length ? q[q.length - 1] : txt).trim();
      }
      el = el.parentElement;
    }
  } catch { /* fall through */ }
  return '';
}

// The parent's FIRST label only belongs to this input if the parent wraps THIS FIELD ALONE.
// Lever lays its form out flat — label, input, label, input, … all in one container — so
// `parentElement.querySelector('label')` returned "Full name*" for EVERY field. The profile
// matcher then saw "full name" in each label and filled the applicant's NAME into the email,
// phone and location fields, and the application was submitted that way: the lever fixture passed
// green while sending "Pierre Salama" as the email address. It only surfaced when the native
// validation gate reported the browser's own complaint —
//   "Please include an '@' in the email address. 'Pierre Salama' is missing an '@'."
// Lever has 0 completed applies in production, consistent with sending malformed applications.
// When the container holds several controls, its first label is whichever control comes first,
// not ours — so skip this source and let label[for] / aria-label / previousElementSibling decide.
function perFieldWrapperLabel(input) {
  try {
    const p = input.parentElement;
    if (!p || typeof p.querySelectorAll !== 'function') return null;
    if (p.querySelectorAll('input:not([type="hidden"]), select, textarea').length > 1) return null;
    return p.querySelector('label, [class*="label"], [class*="Label"]');
  } catch { return null; }
}

export function fieldLabel(input) {
  const root = input.getRootNode?.() || document;
  const sources = [
    elLabelText(input.closest('label')),
    input.id ? elLabelText(root.querySelector?.(`label[for="${cssEscape(input.id)}"]`)) : '',
    input.getAttribute('aria-label'),
    input.getAttribute('aria-labelledby') ? idRefText(root, input.getAttribute('aria-labelledby')) : '',
    elLabelText(input.closest('[role="group"]')?.querySelector('label, [class*="label"], [class*="Label"]')),
    elLabelText(input.previousElementSibling),
    elLabelText(perFieldWrapperLabel(input)),
    // A GENERIC widget placeholder is UI chrome, not the question. Indeed's searchable dropdown
    // renders "Search to select an option", and when no other source resolved, that string became
    // the whole label — so the AI was handed a prompt with no question in it and correctly refused
    // ("The actual application question is missing"), parking the application. Live 2026-07-25 this
    // blocked 6 applications across 6 different employers. Drop the generic ones so the ancestor
    // scan below gets a chance; a SPECIFIC placeholder ("e.g. 5 years") is still useful and kept.
    isGenericPlaceholder(input.placeholder) ? '' : input.placeholder,
    input.name,
  ];
  // Nothing usable yet? The real question often sits in an ancestor block above the widget (the
  // same shape as Indeed's stacked labels). Look upward for the nearest question-like text.
  if (!sources.some((s) => String(s || '').trim() && !isGenericPlaceholder(s))) {
    const near = nearestQuestionText(input);
    if (near) sources.push(near);
  }
  let raw = sources.filter(Boolean).join(' ').toLowerCase().replace(/\s+/g, ' ').trim().slice(0, 300);
  // Collapse an EXACT "A A" doubling (two label sources — e.g. previousElementSibling AND the
  // parent's [class*=label] — returned the same heading), which otherwise reads as gibberish and
  // lowers AI answer confidence. Only the exact two-identical-halves case, so a label that
  // genuinely repeats a word is never altered.
  { const h = raw.length >> 1; if (raw.length % 2 === 1 && raw[h] === ' ' && raw.slice(0, h) === raw.slice(h + 1)) raw = raw.slice(0, h); }
  // Strip TRAILING field-id noise that smartapply (Indeed) and other React ATS leave on the
  // label when the real prompt isn't aria-wired: "languages * <uuid>_1_language",
  // "… fluency_english", "referred by (name) q_<hex>". Left in, it drowns the real text and
  // tanks AI answer confidence (the Indeed 0-submission root cause). END-ANCHORED, looped to
  // peel a stacked tail ("<uuid>_1_language"), and only while ≥4 meaningful chars remain so a
  // legitimate label is never truncated mid-string.
  let prev;
  do { prev = raw; raw = raw.replace(/[\s*]*(?:q_[0-9a-f]{8,}|[0-9a-f]{8}-[0-9a-f-]{12,}|_\d+_[a-z]+|fluency_[a-z]+)$/i, '').trim(); } while (raw !== prev && raw.length >= 4);
  // Return the clean label only. (Previously returned `raw + ' ' + stripAccents(raw)`,
  // which doubled every label — "search" became "search search" — making parked
  // questions read as gibberish to the user AND lowering the AI's answer confidence
  // on real questions. Accent-insensitive matching now happens at the match site,
  // profileFieldFor(), instead of being baked into the label string.)
  return raw;
}

function idRefText(root, ids) {
  return String(ids || '').split(/\s+/)
    .map((id) => elLabelText(root.getElementById?.(id)))
    .join(' ').trim();
}

// A label element's text, reduced to the segment that actually NAMES the field.
//
// ATS labels are often a BLOCK: a section heading, a helper sentence, then the real field name
// last. Captured live from Indeed smartapply 2026-07-20 (the dominant "stuck on a step" failure,
// 17 failed vs 17 done over 7 days), the <label> wired to the required country dropdown was:
//
//   "MOBILE NUMBER
//    Provide valid phone numbers to allow Recruiters to contact you.
//    Country *"
//
// Two things went wrong with that. textContent drops block boundaries, so the words arrived
// JAMMED together ("mobile numberprovide valid phone numbers…country *"). And even spaced, the
// blob matches /phone|mobile/ at index 0 and /country/ only at index 78 -- so the COUNTRY dropdown
// was matched to the phone profile field and "filled" with a phone number, which matches no
// country option. The control stayed empty, Indeed refused to advance, and the re-scan reported
// no unanswered required field because, as far as it could tell, the field had been handled.
//
// Use innerText (block-aware) and, when the label is clearly a stacked block, prefer its LAST
// segment -- the part sitting directly against the control. Conservative on purpose: only when
// there are multiple segments, the last one is short enough to be a field name, and the whole
// blob is long enough to be a heading+helper stack. Anything else returns the text unchanged.
function elLabelText(el) {
  if (!el) return '';
  let t = '';
  try { t = el.innerText || el.textContent || ''; } catch { t = el.textContent || ''; }
  const segs = String(t).split(/\n+/).map((s) => s.trim()).filter(Boolean);
  if (segs.length >= 2) {
    const last = segs[segs.length - 1];
    if (last.length <= 40 && segs.join(' ').length >= 60) return last;
  }
  return t;
}

// Field-id / option-value shapes that must NEVER be emitted as a question label. Deliberately
// NARROW — id shapes + EXACT option-text equality only, never a length or generic-word
// heuristic — so it can't reject a real (even short) question. `optionTexts` is the lowered
// set of the group's own option strings.
export function isLikelyOptionOrId(text, optionTexts) {
  const t = String(text || '').replace(/\s+/g, ' ').trim().toLowerCase();
  if (!t || t.length < 2) return true;
  if (/^(yes|no|oui|non|s[ií]|si|ja|nein|true|false|y|n|n\/?a)$/i.test(t)) return true;          // a bare option word
  if (/\bq_[0-9a-f]{12,}\b/.test(t)) return true;                                                  // smartapply field id (q_<hex>)
  if (/\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/.test(t)) return true;     // uuid
  if (/_\d+_[a-z]+$/.test(t) || /\bfluency_[a-z]+$/.test(t)) return true;                          // _1_language / fluency_english
  if (optionTexts && optionTexts.has(t)) return true;                                              // exact option text
  return false;
}

// Would this string pollute the learned-answer store if saved as a QUESTION?
// Measured on the live store: 143 of 2,576 saved answers (6%) are keyed by junk — React
// element ids ("rn", "r1s", "r20"), bare field names ("name", "email", "city"), and option
// text ("yes", "oui", "easy apply"). They get there when a control has no resolvable label
// and fieldLabel() falls back to input.name / the id. Junk keys are worse than useless: the
// server's qaLookup is FUZZY, so "city" or "name" can match a real question later and answer
// it with the wrong value on a real application.
// Deliberately conservative — a real screening question is multi-word and descriptive, so
// requiring that cannot reject one.
const UI_NOISE_RX = /^(easy apply|apply|apply now|submit|submit application|next|continue|save|back|review|done|yes|no|oui|non|true|false|select|choose|search|name|email|phone|city|country|resume|cv)$/i;
export function isJunkQuestionKey(text) {
  const t = String(text || '').replace(/\s+/g, ' ').trim();
  if (t.length < 8) return true;                       // too short to be a real question
  if (!/\s/.test(t)) return true;                      // single token → a field name or an id
  if (UI_NOISE_RX.test(t)) return true;                // button / option / field-name noise
  if (/^r[0-9a-z]{1,4}$/i.test(t)) return true;        // React-generated element id
  if (/^[«»]/.test(t)) return true;                    // React id rendered with guillemets («rj»)
  if (isLikelyOptionOrId(t, null)) return true;        // q_<hex>, uuid, _N_lang, bare option word
  return false;
}

// The visible option text of a single radio (its <label> text minus the input, id-stripped).
// Used both to build the AI's option list and as the prompt-walk-up blacklist.
// The visible choice text for ONE radio. Order matters: every DOM-authored source is tried
// before input.value, because a radio with no value attribute reports the browser DEFAULT
// "on" — which is not a choice at all. LinkedIn's rebuilt Easy Apply dialog uses NON-wrapping
// <label for="id"> siblings, so closest('label') misses and we used to fall straight through
// to value: every Yes/No group came back as options ["on","on"], unanswerable, so the task
// parked ("needs 1 answer(s)") and "on" even got saved as a learned answer.
function labelTextOf(el) {
  if (!el) return '';
  const c = el.cloneNode(true);
  c.querySelectorAll?.('input,select,textarea').forEach((n) => n.remove());
  return String(c.textContent || '');
}
function optionLabelText(r) {
  try {
    let t = labelTextOf(r.closest?.('label'));
    const root = r.getRootNode?.() || document;
    // non-wrapping <label for="…"> — the standard (and LinkedIn's current) pattern
    if (!t.trim() && r.id) {
      try { t = labelTextOf(root.querySelector?.(`label[for="${cssEscape(r.id)}"]`)); } catch {}
    }
    if (!t.trim()) {
      const ids = String(r.getAttribute?.('aria-labelledby') || '').trim();
      if (ids) t = ids.split(/\s+/).map((id) => { try { return labelTextOf(root.getElementById?.(id) || document.getElementById(id)); } catch { return ''; } }).join(' ');
    }
    if (!t.trim()) t = String(r.getAttribute?.('aria-label') || '');
    t = t.replace(/\s+/g, ' ').trim();
    t = t.replace(/[\s*]*(?:q_[0-9a-f]{8,}|_\d+_[a-z]+)$/i, '').trim();   // drop a trailing field-id if the label was empty
    // LAST resort only, and never the browser's default placeholder value.
    if (!t) { const v = String(r.value ?? '').replace(/\s+/g, ' ').trim(); if (v && !/^(on|off)$/i.test(v)) t = v; }
    if (/^(on|off)$/i.test(t)) t = '';
    return t.slice(0, 60);
  } catch { return ''; }
}

function optionTextsForGroup(input, root) {
  const set = new Set();
  try {
    if (input.type === 'radio' && input.name) {
      for (const r of qsa(`input[type="radio"][name="${cssEscape(input.name)}"]`, root)) {
        const t = optionLabelText(r).toLowerCase();
        if (t) set.add(t);
      }
    }
  } catch {}
  return set;
}

// Generic question-prompt finder for a group whose prompt is NOT aria-wired (Indeed smartapply
// & many React ATS: no <fieldset>, no [role=radiogroup], no aria-labelledby — the question is a
// plain heading/label sitting ABOVE the option row). Find the smallest ancestor that holds the
// whole group, then climb a few levels; at each level take the prompt-shaped element CLOSEST
// BEFORE the first control in document order whose text is clean (not an option/id). Pure DOM;
// returns '' when nothing clean is found (the caller then never falls back to the dirty
// fieldLabel for radios — better a clean skip than asking the AI a non-question).
const PROMPT_SEL = 'legend, [role="heading"], h1, h2, h3, h4, h5, h6, label, [class*="label" i], [class*="question" i], [class*="prompt" i], [class*="title" i], [class*="legend" i], p';
function promptWalkUp(input, optionTexts) {
  try {
    const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
    const root = input.getRootNode?.() || document;
    const opts = optionTexts || optionTextsForGroup(input, root);
    const members = (input.type === 'radio' && input.name)
      ? qsa(`input[type="radio"][name="${cssEscape(input.name)}"]`, root)
      : [input];
    const first = members[0] || input;
    let container = input.parentElement, g = 0;
    while (container && g++ < 10 && !members.every((m) => container.contains?.(m))) container = container.parentElement;
    container = container || input.parentElement || input;
    let node = container, climbs = 0;
    while (node && climbs++ < 6) {
      let best = '';
      for (const el of qsa(PROMPT_SEL, node)) {
        if (el.querySelector?.('input, select, textarea')) continue;          // a wrapper / option label, not the prompt
        const pos = el.compareDocumentPosition?.(first) || 0;
        if (!(pos & 4 /* first FOLLOWS el → el is before the control */)) continue;
        const t = norm(el.textContent);
        if (t.length < 4 || isLikelyOptionOrId(t, opts)) continue;
        best = t;                                                              // doc order → keep the LAST (closest preceding)
      }
      if (best) return best.slice(0, 250);
      if (node.tagName === 'FORM' || node.tagName === 'BODY') break;
      node = node.parentElement;
    }
  } catch {}
  return '';
}

// The QUESTION for a radio group — NOT the per-option "Yes"/"No" label. LinkedIn/
// Greenhouse render Yes/No screening questions as a <fieldset><legend>question</legend>
// (or a [role="radiogroup"]/[role="group"] with aria-label/labelledby), and each radio's
// own <label> is just "Yes"/"No". Using fieldLabel(input) there returns "yes" (3 chars),
// which scanUnknown drops (length<4) → the question is never asked → stuck on Review.
// Walk up to the group to recover the real question text. The structured branches below run
// FIRST (LinkedIn/Greenhouse path, unchanged); only when they yield nothing do the generic
// smartapply/React paths run — so LinkedIn never reaches the new code.
export function radioGroupLabel(input) {
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const fs = input.closest?.('fieldset');
  if (fs) {
    const lg = norm(fs.querySelector?.('legend')?.textContent);
    if (lg.length >= 4) return lg;
  }
  const grp = input.closest?.('[role="radiogroup"], [role="group"], [data-test-form-builder-radio-button-form-component], fieldset');
  if (grp) {
    const al = norm(grp.getAttribute?.('aria-label'));
    if (al.length >= 4) return al;
    const lb = grp.getAttribute?.('aria-labelledby');
    if (lb) { const t = norm(idRefText(grp.getRootNode?.() || document, lb)); if (t.length >= 4) return t; }
    const lab = norm(grp.querySelector?.('legend, [class*="fb-dash-form-element__label"], label, [class*="label"], [class*="Label"]')?.textContent);
    if (lab.length >= 4) return lab;
  }
  // ── smartapply / React (no fieldset/role/aria-wiring) ──
  const root = input.getRootNode?.() || document;
  const opts = optionTextsForGroup(input, root);
  const ilb = input.getAttribute?.('aria-labelledby');
  if (ilb) { const t = norm(idRefText(root, ilb)); if (t.length >= 4 && !isLikelyOptionOrId(t, opts)) return t.slice(0, 250); }
  return promptWalkUp(input, opts);
}

// The QUESTION for a <select> whose label isn't formally associated (smartapply's
// "languages * <uuid>_1_language" / "fluency_english" — the field-id leaks through as the
// label). A clean direct label wins (covers labelled selects everywhere incl. LinkedIn);
// only an id-shaped direct label triggers the generic prompt walk-up.
export function selectGroupLabel(input) {
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const direct = norm(fieldLabel(input));
  if (direct.length >= 4 && !isLikelyOptionOrId(direct, null) && !/_\d+_[a-z]+$|q_[0-9a-f]{12,}|[0-9a-f]{8}-[0-9a-f]{4}/.test(direct)) return direct.slice(0, 250);
  return promptWalkUp(input, null) || direct.slice(0, 250);
}

function cssEscape(s) {
  return (window.CSS && CSS.escape) ? CSS.escape(s) : String(s).replace(/([^\w-])/g, '\\$1');
}

// Site chrome that must NEVER be filled: the global search bar / typeahead and anything
// living in the page header/nav. Root cause of the "executor types into LinkedIn's global
// search bar (value '0')" bug — a broad fill root (dialog || detectApplyForm container)
// can include the site header before the apply modal opens. Shared by scanFillable,
// scanUnknown, fill(), and fillCombobox so the guard is enforced consistently everywhere.
// Defensive: any error → false (don't let a guard exception block real fills).
const SITE_CHROME_SEL = 'header, nav, [role="banner"], [role="navigation"], [class*="global-nav"], [id*="global-nav"], [class*="search-global"], [class*="typeahead"][class*="search"], [data-test-global-nav], #global-nav, .search-global-typeahead';
export function isSiteChromeInput(input) {
  try {
    if (!input) return false;
    // 1) It's a search box.
    if (input.type === 'search') return true;
    const role = input.getAttribute?.('role');
    const label = fieldLabel(input);
    if (role === 'combobox' && /^\s*search\b/i.test(label)) return true;
    if (/^\s*search(\s+search)*\s*$/i.test(label)) return true;
    // 2) It lives inside site chrome (header/nav/global-nav/global-search typeahead).
    if (input.closest?.(SITE_CHROME_SEL)) return true;
    return false;
  } catch { return false; }
}

function profileFieldFor(label, profile) {
  // Match against both the raw and accent-folded label so French fields (e.g.
  // "prénom") still hit patterns even where only the unaccented form is listed.
  const folded = stripAccents(label);
  // A "how many years / how long / experience with X" question wants a NUMBER — it must
  // NOT be filled with a profile URL/handle that merely mentions X (e.g. "years of
  // experience with GitHub" was grabbing the GitHub URL → "Invalid input"). Skip URL
  // fields for these; the AI estimates the years from the resume instead.
  const wantsQuantity = /\b(how many|how long|years?|number of|combien|nombre d)\b/i.test(label) || /\byears?\b/i.test(folded);
  for (const [rx, field] of PROFILE_PATTERNS) {
    if (wantsQuantity && /Url$/.test(field)) continue;
    // Only scalar profile values are fillable — never stringify an array/object
    // (e.g. workHistory) into a form field.
    if ((rx.test(label) || rx.test(folded)) && profile[field] != null && profile[field] !== '' && typeof profile[field] !== 'object') {
      return { field, value: profile[field] };
    }
  }
  return null;
}

// EEO / demographic / criminal-history fields are NEVER auto-filled, escalated to AI,
// or harvested — regardless of settings (legal/ethical). Mirrors executor.js.
export const NEVER_AUTOFILL_RX = /(ethnic|race|gender|disabilit|veteran|criminal|background.?check|felony|conviction|pronoun|sexual.?orientation|\blgbtq?)/i;

// A radio/checkbox is "visible enough" to be a real screening control when the native input
// OR an associated <label> / styled wrapper is visible. LinkedIn (and many ATS) render the
// native <input type=radio> as a 0x0 / clipped / opacity:0 box behind a styled label, so a
// strict isProbablyVisible(input) check made the entire "Authorized to work? Yes/No" screening
// question INVISIBLE to the scanner — the form then silently refused to advance ("stuck on a
// step", the single largest failure bucket). Confirmed by live transcripts where the Oui/Non
// group was in the page text but absent from the scanned field set.
function isControlOrLabelVisible(input) {
  if (isProbablyVisible(input)) return true;
  try {
    const doc = input.ownerDocument || document;
    const lab = input.closest('label')
      || (input.id && doc.querySelector(`label[for="${cssEscape(input.id)}"]`))
      || input.closest('[role="radio"],[role="checkbox"],[data-test-text-selectable-option],[class*="radio"],[class*="checkbox"],[class*="selectable-option"]');
    return !!(lab && isProbablyVisible(lab));
  } catch { return false; }
}

export function isFillable(input) {
  if (!input) return false;
  if (input.disabled || input.readOnly) return false;
  if (input.type && ['hidden', 'file', 'submit', 'button', 'image', 'reset'].includes(input.type)) return false;
  // Radios/checkboxes: judge visibility via the input OR its label/wrapper (the native input is
  // often visually hidden for styling). Everything else: the input itself must be visible.
  if (input.type === 'radio' || input.type === 'checkbox') {
    if (!isControlOrLabelVisible(input)) return false;
  } else if (!isProbablyVisible(input)) {
    return false;
  }
  const id = (input.id || '') + ' ' + (input.name || '') + ' ' + (input.placeholder || '');
  if (/captcha|recaptcha|cardnumber|cvv|cvc|password/i.test(id)) return false;
  if (NEVER_AUTOFILL_RX.test(id)) return false;
  if (input.type === 'password') return false;
  return true;
}

// LinkedIn prefills some REQUIRED numeric screening inputs ("How many years … with X?") with a
// junk placeholder "1" (the "1 of 20 characters" counter). The non-empty guards below would treat
// that as "already answered" and silently submit "1 year" without ever asking — a trust-eroding
// false answer. A lone digit in a REQUIRED field that WE have NOT filled is therefore treated as
// UNanswered so it surfaces to the answer layer (grounded estimate or honest park). Once we fill it
// (any value) it is "ours" (marked in setNativeValue) and never re-surfaced — so a legit single-digit
// answer ("0"/"6" years) can't loop: fill → re-detected as placeholder → re-fill → …
const _jatFilledFields = new WeakSet();
function looksPrefilledPlaceholder(input) {
  try {
    if (!input || input.tagName === 'SELECT') return false;
    if (_jatFilledFields.has(input)) return false;   // we already answered it — not a placeholder
    const required = input.required || input.getAttribute('aria-required') === 'true';
    return required && /^\d$/.test(String(input.value || '').trim());
  } catch { return false; }
}

// ---- résumé upload detection (B4: Glassdoor / external company-site uploads) ----
// Affordance text/attrs that mean "this is the résumé/CV upload control". Broad on
// purpose: Glassdoor & many ATS hide the real <input type=file> behind a styled
// "Upload resume" / "Attach resume" button, so the resume-ish text is on a sibling and
// the input itself may have no label. PURE (string + attrs only) so it's node-testable.
export const RESUME_HINT_RX = /(resume|résumé|\bcv\b|curriculum|upload.*\b(resume|cv|file|document)\b|attach.*\b(resume|cv|file)\b|joindre|téléverser|drag.*drop|choose file|select file|\.pdf|\.docx?)/i;
export const DOC_ACCEPT_RX = /(pdf|msword|officedocument|\.docx?|\.pdf|\.rtf|\.txt)/i;

// isResumeFileInput(input, ctxText) — does this file input look like the résumé upload?
// `ctxText` is the surrounding affordance text (label + nearby button/dropzone), lowered
// by the caller. Matches on that text OR a document-typed `accept` attribute. Hidden
// inputs still qualify (custom widgets hide the real input) — visibility is the caller's
// call. Guarded: any error → false.
export function isResumeFileInput(input, ctxText = '') {
  try {
    if (!input) return false;
    const accept = (input.getAttribute?.('accept') || '');
    return RESUME_HINT_RX.test(ctxText || '') || DOC_ACCEPT_RX.test(accept);
  } catch { return false; }
}

// Normalized Levenshtein similarity in [0,1] (1 = identical) — tiny, self-contained,
// NO dependency. Used as the FINAL fuzzy tier in matchOption/pickRadioInGroup so a
// paraphrased AI/learned answer snaps to a real option ("Bachelors" → "Bachelor's
// Degree", "5-7 yrs" → "5 to 7 years", "Yes" → "Yes, I am authorized to work").
// Whitespace-/case-/punctuation-folded so trivial formatting differences don't cost
// distance. Conservative by design — the caller gates on FUZZY_SNAP_MIN so garbage
// still parks; this never mis-selects on its own.
export const FUZZY_SNAP_MIN = 0.72;
function normForFuzzy(s) {
  return String(s == null ? '' : s)
    .toLowerCase()
    // Canonicalize a few high-frequency answer abbreviations so a paraphrase scores against
    // the same surface form as the option ("5-7 yrs" ≈ "5 to 7 years"). Conservative + tiny;
    // it only normalizes spelling, it does not invent meaning.
    .replace(/\byrs?\b/g, 'years')
    .replace(/(\d)\s*[-–—]\s*(\d)/g, '$1 to $2')   // "5-7" → "5 to 7" (range dash → "to")
    .replace(/\bgrad\b/g, 'graduate')
    .replace(/[^a-z0-9]+/g, ' ')   // fold remaining punctuation/apostrophes to spaces
    .replace(/\s+/g, ' ')
    .trim();
}
function levenshtein(a, b) {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  let cur = new Array(b.length + 1);
  for (let i = 1; i <= a.length; i++) {
    cur[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      cur[j] = Math.min(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
    }
    [prev, cur] = [cur, prev];
  }
  return prev[b.length];
}
function levSim(x, y) {
  if (!x || !y) return 0;
  if (x === y) return 1;
  const maxLen = Math.max(x.length, y.length);
  return maxLen ? 1 - levenshtein(x, y) / maxLen : 0;
}
// Similarity in [0,1]. Combines whole-string normalized Levenshtein with a TOKEN-aware
// measure so a SHORT answer that is the meaningful subset of a longer option still scores
// high ("Bachelors" ⊂ "Bachelor's Degree", "Yes" ⊂ "Yes, I am authorized to work") — the
// whole-string metric alone over-penalizes that length gap. Token measure: for each token of
// the shorter side, take its BEST per-token Levenshtein similarity against the longer side's
// tokens, then average — so unrelated answers (no token aligns) still score low and PARK.
export function fuzzySimilarity(a, b) {
  const x = normForFuzzy(a);
  const y = normForFuzzy(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  const whole = levSim(x, y);
  const xt = x.split(' ').filter(Boolean);
  const yt = y.split(' ').filter(Boolean);
  const [short, long] = xt.length <= yt.length ? [xt, yt] : [yt, xt];
  let tokenScore = 0;
  if (short.length) {
    let sum = 0;
    for (const t of short) {
      let best = 0;
      for (const u of long) { const s = levSim(t, u); if (s > best) best = s; }
      sum += best;
    }
    tokenScore = sum / short.length;
  }
  return Math.max(whole, tokenScore);
}
// Score `value` against every candidate label and return the index of the best ONLY
// when its similarity clears `min` (default FUZZY_SNAP_MIN); else null → caller parks.
export function bestFuzzyIndex(labels, value, min = FUZZY_SNAP_MIN) {
  let best = -1, bestScore = 0;
  labels.forEach((lbl, i) => {
    const score = fuzzySimilarity(value, lbl);
    if (score > bestScore) { bestScore = score; best = i; }
  });
  return bestScore >= min ? best : null;
}

// Pick the best <option> for a value, preferring exactness over substring so
// '5' selects '5+ years' / '5-10 years' (longest containing match), never the
// first DOM-order option that merely contains the digit ('3-5 years').
export function matchOption(select, v) {
  const opts = Array.from(select.options);
  const vl = String(v).toLowerCase();
  const exact = opts.find((o) => o.value === v || o.text === v)
    || opts.find((o) => o.value.toLowerCase() === vl || o.text.toLowerCase().trim() === vl);
  if (exact) return exact;
  // Numeric answer (years-of-experience, salary band) → pick the option whose RANGE
  // contains it, so '6' selects '5-10 years' not '16+ years' by accidental substring.
  const ni = numericMatch(opts.map((o) => o.text), v);
  if (ni != null) return opts[ni];
  const sub = opts
    .filter((o) => o.text.toLowerCase().includes(vl) || o.value.toLowerCase().includes(vl))
    .sort((a, b) => b.text.length - a.text.length)[0];
  if (sub) return sub;
  // FINAL fuzzy tier: snap a paraphrased answer to the closest real option label, but
  // ONLY when similarity is high enough (conservative) — otherwise return null (park).
  // Never mis-selects garbage: a low-similarity answer falls through to null. Skip the
  // synthetic "Select…/Choose…/--" placeholder so we never snap onto the empty default.
  const labels = opts.map((o) => (o.text || '').trim());
  const fi = bestFuzzyIndex(labels, v);
  if (fi != null && !/^select|^choose|^--|^$/i.test(labels[fi])) return opts[fi];
  return null;
}

// If `value` is a bare number (optionally $/years/k), return the INDEX of the label
// whose numeric range contains it (tightest range wins; "N+" thresholds pick the
// largest floor ≤ value). Returns null for non-numeric answers so prose is untouched.
export function numericMatch(labels, value) {
  const s = String(value).trim();
  if (!/^\$?\s*\d[\d,.]*\s*\+?\s*(years?|yrs?|k)?\.?$/i.test(s)) return null;
  const n = Number(s.replace(/[^\d.]/g, ''));
  if (!Number.isFinite(n)) return null;
  let inRange = -1, span = Infinity, plus = -1, plusLo = -Infinity;
  labels.forEach((raw, i) => {
    const t = String(raw).replace(/,/g, '');
    let m;
    if ((m = t.match(/(\d+(?:\.\d+)?)\s*(?:[-–—]|to)\s*(\d+(?:\.\d+)?)/i))) {
      const lo = +m[1], hi = +m[2];
      if (n >= lo && n <= hi && (hi - lo) < span) { inRange = i; span = hi - lo; }
    } else if ((m = t.match(/(\d+(?:\.\d+)?)\s*\+/))) {
      const lo = +m[1];
      if (n >= lo && lo > plusLo) { plusLo = lo; plus = i; }
    }
  });
  return inRange >= 0 ? inRange : (plus >= 0 ? plus : null);
}

// Pick the radio in `input`'s group whose LABEL best matches the answer value — the
// radio analogue of matchOption (years-of-experience, work-authorization, and salary
// bands are radio groups, so a confident AI answer like "5-7 years" must select the
// matching option, not be discarded by the old yes/no-only check).
export function pickRadioInGroup(input, v) {
  let group;
  try {
    group = input.name
      ? Array.from((input.getRootNode() || document).querySelectorAll(`input[type="radio"][name="${CSS.escape(input.name)}"]`))
      : [input];
  } catch { group = [input]; }
  if (!group.length) return null;
  const vl = String(v).toLowerCase().replace(/\s+/g, ' ').trim();
  if (!vl) return null;
  const labelled = group
    .map((r) => ({ r, lbl: String(fieldLabel(r) || r.value || '').toLowerCase().replace(/\s+/g, ' ').trim() }))
    .filter((x) => x.lbl);
  const hit = labelled.find((x) => x.lbl === vl)
    || labelled.filter((x) => x.lbl.includes(vl) || vl.includes(x.lbl)).sort((a, b) => b.lbl.length - a.lbl.length)[0]
    || null;
  if (hit) return hit.r;
  // FINAL fuzzy tier (matches matchOption): snap a paraphrased answer to the closest
  // radio label, but ONLY above the conservative FUZZY_SNAP_MIN — else null (park). So
  // "Yes" → "Yes, I am authorized to work", "Bachelors" → "Bachelor's Degree"; garbage
  // (no label clears the bar) still returns null and is parked, never mis-selected.
  const fi = bestFuzzyIndex(labelled.map((x) => x.lbl), v);
  return fi != null ? labelled[fi].r : null;
}

// React-proof value injection.
export function setNativeValue(el, value) {
  try {
    const proto = Object.getPrototypeOf(el);
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set
      || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
  } catch { el.value = value; }
  try { _jatFilledFields.add(el); } catch {}   // mark as answered-by-us (see looksPrefilledPlaceholder)
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
}

// Fill custom comboboxes / typeaheads / react-selects (Workday, Greenhouse, Lever, and
// LinkedIn's own dropdowns INCLUDING the "Location (city)" typeahead — the #1 ATS gap).
// You can't just TYPE these: LinkedIn requires you to PICK a suggestion, and that list
// renders ASYNC after typing — so we type, WAIT for the options, then click the match.
// FULLY wrapped: any failure is a no-op (field left for the AI/park path) — never regresses.
const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));
export async function fillCombobox(el, value) {
  try {
    if (isSiteChromeInput(el)) return false;   // never type into the global search typeahead
    const v = String(value == null ? '' : value).trim();
    if (!v) return false;
    const vl = v.toLowerCase();
    el.focus?.();
    // Open with the FULL pointer sequence, not just mousedown+click. Measured live on Indeed
    // smartapply 2026-07-20: the required country dropdown is a <div role="combobox"
    // aria-haspopup="dialog">, and a bare .click() left aria-expanded="false" (no option list
    // rendered at all) while the pointerover/pointerdown/pointerup/click sequence flipped it to
    // "true" and rendered 242 options. React widgets bind pointer events, so a control that never
    // opens yields no options, no pick, and a required field left silently empty.
    try {
      ['pointerover', 'mouseover', 'mousemove', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']
        .forEach((ev) => el.dispatchEvent(new MouseEvent(ev, { bubbles: true, cancelable: true, view: window })));
    } catch {
      try { el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); } catch {}
      try { el.click?.(); } catch {}
    }
    // Typeable combobox/typeahead (location, etc.): type the value to trigger suggestions.
    if (el.tagName === 'INPUT' || el.isContentEditable) {
      try { setNativeValue(el, v); } catch {}
      try { el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: v.slice(-1) })); } catch {}
      try { el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: v.slice(-1) })); } catch {}
    }
    // WAIT (up to ~3.5s) for the option list to render — async typeaheads need this.
    const SEL = '[role="option"], [role="listbox"] li, [class*="typeahead"] [role="option"], [class*="typeahead-result"], .basic-typeahead__selectable, [class*="select__option"], [class*="-option"], li[role="option"]';
    let opts = [];
    for (let i = 0; i < 14; i++) {
      opts = qsa(SEL, document).filter((o) => o && o.offsetParent !== null && (o.textContent || '').trim());
      if (opts.length) break;
      await sleepMs(250);
    }
    const txt = (o) => (o.textContent || '').trim().toLowerCase();
    // exact → the typed text is a prefix of the option (LinkedIn location: "Toronto, ON"
    // → "Toronto, Ontario, Canada") → substring. NO blind first-option pick (would mis-fill
    // a real dropdown like years-of-experience).
    let pick = opts.find((o) => txt(o) === vl)
      || opts.find((o) => txt(o).startsWith(vl) && vl.length > 1)
      || opts.find((o) => vl.startsWith(txt(o)) && txt(o).length > 2)
      || opts.find((o) => txt(o).includes(vl) && vl.length > 2);
    // A numeric answer against RANGE options ("6" vs "5-10 years") matches nothing textually —
    // resolve it by arithmetic instead, else the widget stays unselected and the form won't advance.
    if (!pick) {
      const ri = matchNumericRangeOption(v, opts.map((o) => txt(o)));
      if (ri >= 0) pick = opts[ri];
    }
    if (!pick) {
      try { el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); } catch {}
      return false;
    }
    try { pick.scrollIntoView?.({ block: 'nearest' }); } catch {}
    try { pick.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); } catch {}
    try { pick.dispatchEvent(new MouseEvent('mouseup', { bubbles: true })); } catch {}
    try { pick.click?.(); } catch {}
    await sleepMs(150);
    return true;
  } catch { return false; }
}

export class AutofillEngine {
  // { getProfile: async ()=>data{}, lookupAnswer: async (label)=>({answer}|null),
  //   recordAnswer: async ({question,answer,fieldType,source,jobId})=>void, log }
  constructor({ getProfile, lookupAnswer, recordAnswer, log }) {
    this.getProfile = getProfile;
    this.lookupAnswer = lookupAnswer;
    this.recordAnswer = recordAnswer;
    this.log = log || (() => {});
    this.recordedKeys = new Set();
  }

  fields(rootEl) {
    // Include custom comboboxes / react-selects ([role=combobox] divs + react-select
    // inputs), not just native controls — these are the required ATS/LinkedIn dropdowns
    // that, left unfilled, made "Review"/"Next" silently refuse to advance (the dominant
    // "stuck on a step" failure). fill() routes them to fillCombobox().
    return qsa('input, textarea, select, [role="combobox"]', rootEl || document);
  }

  // Empty fillable fields + a suggestion for each (profile first, then qa).
  // `onSkip(reason, input, label)` is an OPTIONAL diagnostic side-channel (behavior-neutral).
  // It exists because "fillable=0 while a required control blocks the step" is the dominant
  // live park and could not be reproduced in the harness — so the engine has to say WHY it
  // passed over every field. Only the executor's trace consumes it, and only when nothing
  // was fillable.
  async scanFillable(rootEl, onSkip) {
    const profile = await this.getProfile();
    const out = [];
    const skip = (reason, input, label) => { try { onSkip?.(reason, input, label); } catch {} };
    for (const input of this.fields(rootEl)) {
      if (!isFillable(input)) { skip('not-fillable', input); continue; }
      if (isSiteChromeInput(input)) { skip('site-chrome', input); continue; }   // never touch the global search bar / header chrome
      // NOTE on radios reading as "already-has-value" here: that is BY DESIGN, not a bug.
      // A radio reports the browser default "on" even when unchecked, so it trips this test —
      // and that is fine, because radios are deliberately NOT handled by scanFillable at all.
      // They need an OPTION SELECTED, not a profile string typed in, so scanUnknown routes them
      // to the answer path (groundedEligibilityAnswer / AI → pickRadioInGroup) using the GROUP's
      // question via radioGroupLabel(). Pulling them in here makes fieldLabel() return the
      // per-option text ("Yes"), which is the "yes yes q_<id>" garbage that once parked every
      // Indeed job — the indeed-smartapply-radios fixtures fail immediately if that regresses.
      if (input.tagName !== 'SELECT' && input.value && String(input.value).trim() && !looksPrefilledPlaceholder(input)) { skip('already-has-value', input); continue; }
      if (input.tagName === 'SELECT' && input.selectedIndex > 0) { skip('select-already-chosen', input); continue; }
      if ((input.type === 'checkbox' || input.type === 'radio') && input.checked) { skip('already-checked', input); continue; }
      const label = fieldLabel(input);
      if (!label) { skip('no-label', input); continue; }
      if (NEVER_AUTOFILL_RX.test(label)) { skip('never-autofill', input, label); continue; }
      const pm = profileFieldFor(label, profile || {});
      if (pm) { out.push({ input, label, source: 'profile', field: pm.field, value: pm.value }); continue; }
      const qa = await this.lookupAnswer(label);
      if (qa?.answer) { out.push({ input, label, source: 'qa', value: qa.answer, qa }); continue; }
      skip('no-profile-or-qa-answer', input, label);
    }
    return out;
  }

  // Empty fields we have NO answer for — the executor escalates these to AI.
  async scanUnknown(rootEl) {
    const profile = await this.getProfile();
    const out = [];
    const seenRadioGroups = new Set();
    for (const input of this.fields(rootEl)) {
      if (!isFillable(input)) continue;
      if (isSiteChromeInput(input)) continue;   // never surface the global search bar / header chrome
      if (input.type === 'radio') {
        const group = input.name || fieldLabel(input);
        if (seenRadioGroups.has(group)) continue;
        seenRadioGroups.add(group);
        const groupChecked = input.name
          ? qsa(`input[type="radio"][name="${cssEscape(input.name)}"]`, rootEl || document).some((r) => r.checked)
          : input.checked;
        if (groupChecked) continue;
      } else if (input.type === 'checkbox') {
        continue;   // never auto-decide bare checkboxes (consents etc.)
      } else if (input.tagName === 'SELECT') {
        if (input.selectedIndex > 0 && input.value) continue;
      } else if (input.value && String(input.value).trim() && !looksPrefilledPlaceholder(input)) {
        continue;
      }
      // For radios, the per-option <label> is just "Yes"/"No" — use the group's
      // legend/question instead so the screening question is actually surfaced. Radios NEVER
      // fall back to fieldLabel (that produced the "yes yes q_<id>" garbage on smartapply →
      // the AI got a non-question → parked every Indeed job). SELECTs use the prompt-recovering
      // resolver (id-shaped names → heading walk-up). A radio with no recoverable prompt is
      // skipped (length<4 below) rather than asked with garbage.
      let label;
      if (input.type === 'radio') label = radioGroupLabel(input);
      else if (input.tagName === 'SELECT') label = selectGroupLabel(input);
      else label = fieldLabel(input);
      if (!label || label.length < 4) continue;
      if (NEVER_AUTOFILL_RX.test(label)) continue;
      // (Generic site-search / global-search typeahead inputs are already skipped above
      // via isSiteChromeInput — they're never a real application question and would
      // falsely park the whole job at submit.)
      // Non-radio fields defer to the profile (a string we can type). RADIOS, however, need an
      // OPTION SELECTED, not a string typed — the profile stores text (e.g. the workAuthorization
      // sentence) that can't be typed into a Yes/No radio. So route radios to the answer path
      // (groundedEligibilityAnswer / AI → pickRadioInGroup) even when the profile "matches" the
      // group question, instead of skipping them here and silently leaving the group unanswered
      // (which blocked "Review"/"Next" → the "stuck on a step" failure).
      if (input.type !== 'radio' && profileFieldFor(label, profile || {})) continue;
      if (await this.lookupAnswer(label)) continue;
      // Required-detection: smartapply's loose Yes/No radios carry NO input.required/aria-required
      // (the marker lives on the prompt container), so they read as "optional" and the recover
      // path — which only grounds REQUIRED fields — skipped them → eligibility never answered.
      // ADDITIVE-OR with the prompt-container / prompt-text marker so they're treated as blocking.
      const required = input.required || input.getAttribute('aria-required') === 'true'
        || !!input.closest?.('[aria-required="true"], [class*="required" i], [data-required]')
        || /[*]|\brequired\b|\brequis\b|\bobligatoire\b/i.test(label);
      let options = null;
      if (input.tagName === 'SELECT') {
        options = Array.from(input.options).map((o) => (o.textContent || '').trim()).filter((t) => t && !/^select|^choose|^--/i.test(t)).slice(0, 30);
      } else if (input.type === 'radio' && input.name) {
        options = qsa(`input[type="radio"][name="${cssEscape(input.name)}"]`, rootEl || document)
          .map((r) => optionLabelText(r)).filter(Boolean).slice(0, 12);
      }
      out.push({ input, label: label.slice(0, 250), required, fieldType: input.type || input.tagName.toLowerCase(), options });
    }
    return out;
  }

  // fill(suggestions, onOutcome?) — fills each suggested field. `onOutcome` is an
  // OPTIONAL, behavior-neutral side-channel for forensic logging: it is invoked with
  // ({ suggestion, outcome, detail }) for every field (filled OR skipped) and its
  // return value is ignored. It NEVER changes what gets filled or the returned count —
  // it only observes (so the executor can write a per-field FILL-OUTCOME trace line).
  // outcome ∈ filled | fuzzy-snapped | skipped-no-option | skipped-not-yes |
  //          skipped-site-chrome | skipped-combobox-miss | error.
  async fill(suggestions, onOutcome) {
    const emit = typeof onOutcome === 'function'
      ? (suggestion, outcome, detail) => { try { onOutcome({ suggestion, outcome, detail }); } catch {} }
      : () => {};
    let n = 0;
    for (const s of suggestions) {
      try {
        if (isSiteChromeInput(s.input)) { emit(s, 'skipped-site-chrome'); continue; }   // belt-and-suspenders: never fill site chrome
        const v = String(s.value);
        const isCombo = s.input.getAttribute && (s.input.getAttribute('role') === 'combobox'
          || (s.input.closest && s.input.closest('[class*="select__control"],[class*="react-select"],[class*="-control"],[class*="basic-typeahead"]')));
        // Indeed's searchable dropdown is a PLAIN <input type=text> — no role="combobox", no
        // react-select class — whose placeholder ("Search to select an option") is the only hint
        // that it expects a PICK, not typing. Typing into it leaves the widget unselected, so the
        // form refuses to advance while the field looks filled. Detected via the placeholder and
        // driven through the combobox path, with a fall-back to plain typing if no option list
        // ever appears, so a genuinely-free-text field can never regress.
        const isSearchableSelect = !isCombo && looksLikeSearchableSelect(s.input);
        if (s.input.tagName === 'SELECT') {
          const opt = matchOption(s.input, v);
          if (!opt) { emit(s, 'skipped-no-option'); continue; }
          setNativeValue(s.input, opt.value);
          // Detect a fuzzy snap: the chosen option text isn't an exact/substring of the value.
          const snapped = !(opt.value === v || opt.text === v
            || String(opt.value).toLowerCase() === v.toLowerCase()
            || String(opt.text).toLowerCase().trim() === v.toLowerCase().trim());
          emit(s, snapped ? 'fuzzy-snapped' : 'filled', snapped ? (opt.text || opt.value) : undefined);
        } else if (isCombo || isSearchableSelect) {
          // custom dropdown / typeahead (Workday/Greenhouse/Lever/LinkedIn location) — async
          if (!(await fillCombobox(s.input, v))) {
            if (!isSearchableSelect) { emit(s, 'skipped-combobox-miss'); continue; }
            setNativeValue(s.input, v);          // no options appeared → it really was free text
            emit(s, 'filled');
          } else emit(s, 'filled');
        } else if (s.input.type === 'radio') {
          // Radio GROUPS (years-of-experience, work-authorization, salary band) are
          // not yes/no — pick the option in the group whose label best matches the
          // answer. Falls back to the old yes-token behaviour for boolean radios.
          const picked = pickRadioInGroup(s.input, v);
          const target = picked || (/^(yes|true|y|oui|sí|si|ja|1)$/i.test(v) ? s.input : null);
          if (!target) { emit(s, 'skipped-no-option'); continue; }
          target.checked = true;
          target.dispatchEvent(new Event('input', { bubbles: true }));
          target.dispatchEvent(new Event('change', { bubbles: true }));
          emit(s, 'filled');
        } else if (s.input.type === 'checkbox') {
          const yes = /^(yes|true|y|oui|sí|si|ja|1)$/i.test(v);
          if (!yes) { emit(s, 'skipped-not-yes'); continue; }
          s.input.checked = true;
          s.input.dispatchEvent(new Event('input', { bubbles: true }));
          s.input.dispatchEvent(new Event('change', { bubbles: true }));
          emit(s, 'filled');
        } else {
          setNativeValue(s.input, v);
          emit(s, 'filled');
        }
        n++;
      } catch (e) { emit(s, 'error', e?.message); }
    }
    return n;
  }

  // Record every (label, value) pair → qa store. Call on submit / step advance.
  async captureCurrentAnswers(rootEl, { source, jobId } = {}) {
    let n = 0;
    for (const input of this.fields(rootEl)) {
      if (!isFillable(input)) continue;
      if (input.type === 'radio' && !input.checked) continue;   // only the chosen option
      // Use the prompt-recovering resolver so the qa key is the real question (not "yes yes
      // q_<id>") — that's what makes a smartapply screening answer REUSABLE across jobs.
      let label;
      if (input.type === 'radio') label = radioGroupLabel(input);
      else if (input.tagName === 'SELECT') label = selectGroupLabel(input);
      else label = fieldLabel(input);
      if (!label || label.length < 3) continue;
      if (NEVER_AUTOFILL_RX.test(label)) continue;
      let value = '';
      if (input.tagName === 'SELECT') {
        const opt = input.options[input.selectedIndex];
        value = opt ? (opt.text || opt.value) : '';
      } else if (input.type === 'checkbox' || input.type === 'radio') {
        if (!input.checked) continue;
        value = input.value || 'Yes';
      } else {
        value = String(input.value || '').trim();
      }
      if (!value || /^(\*+|•+)$/.test(value) || value.length > 1500) continue;
      const key = `${source || 'any'}::${label}`;
      if (this.recordedKeys.has(key)) continue;
      this.recordedKeys.add(key);
      await this.recordAnswer({ question: label.slice(0, 400), answer: value, fieldType: input.type, source, jobId });
      n++;
    }
    return n;
  }

  // Learn from values the site pre-filled (LinkedIn/Indeed/Workday do this).
  async harvestPrefilledValues(rootEl, opts = {}) {
    return this.captureCurrentAnswers(rootEl, { ...opts, source: (opts.source || 'any') + ':prefill' });
  }
}
